package src.comitton.pdf.data;

public class ImageLzw {
	public int columns;
	public int colors;
	public int predictor;
	public int bpc;
	public int ec;
}
