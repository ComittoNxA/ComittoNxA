package src.comitton.pdf.data;

public class PictureData {
	public String mFileName;
	public int mWidth;
	public int mHeight;
	public boolean mIsError = false;
}
