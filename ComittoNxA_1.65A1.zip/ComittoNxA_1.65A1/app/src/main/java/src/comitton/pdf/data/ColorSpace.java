package src.comitton.pdf.data;

public class ColorSpace {
	public String name;
	public int n;
}
