package src.comitton.pdf.data;

public class ImageFlate {
	public int columns;
	public int colors;
	public int predictor;
	public int bpc;
}
