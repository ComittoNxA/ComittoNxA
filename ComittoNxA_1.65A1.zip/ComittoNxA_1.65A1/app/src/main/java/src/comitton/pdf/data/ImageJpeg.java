package src.comitton.pdf.data;

public class ImageJpeg {
	public int ct;
}
