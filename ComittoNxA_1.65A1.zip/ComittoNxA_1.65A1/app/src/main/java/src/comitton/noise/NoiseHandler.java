package src.comitton.noise;

public interface NoiseHandler {
	public void onNotice(int level[]);
}