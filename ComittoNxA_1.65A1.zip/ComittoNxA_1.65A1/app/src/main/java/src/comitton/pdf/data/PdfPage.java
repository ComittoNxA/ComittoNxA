package src.comitton.pdf.data;

public class PdfPage {
	public int rotate;
	public int transparency;
//	public PdfAnnot  annots;
	public PdfObject resources;
	public PdfObject contents;
}
