package src.comitton.pdf.data;

public class ImageFax {
	public int columns;
	public int rows;
	public int k;
	public boolean eol;
	public boolean eba;
	public boolean eob;
	public boolean bi1;
}
