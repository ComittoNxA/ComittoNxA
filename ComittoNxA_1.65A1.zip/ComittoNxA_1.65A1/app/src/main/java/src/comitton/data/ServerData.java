package src.comitton.data;

public class ServerData {
	private String mName = "";
	private String mHost = "";
	private String mUser = "";
	private String mPass = "";
	private String mPath = "";

	public String getName() {
		return this.mName;
	}

	public void setName(String name) {
		this.mName = name;
	}

	public String getHost() {
		return this.mHost;
	}

	public void setHost(String host) {
		this.mHost = host;
	}

	public String getUser() {
		return this.mUser;
	}

	public void setUser(String user) {
		this.mUser = user;
	}

	public String getPass() {
		return this.mPass;
	}

	public void setPass(String pass) {
		this.mPass = pass;
	}

	public String getPath() {
		return this.mPath;
	}

	public void setPath(String path) {
		this.mPath = path;
	}
}
