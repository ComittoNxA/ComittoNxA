package src.comitton.pdf.data;


public class PdfInfo {
//	public PdfObject resources;
//	public PdfObject mediabox;
//	public PdfObject cropbox;
	public PdfObject rotate;
}
