package src.comitton.pdf.data;

public class PdfAnnot {
	public int rotate;
	public PdfAnnot next;
}
