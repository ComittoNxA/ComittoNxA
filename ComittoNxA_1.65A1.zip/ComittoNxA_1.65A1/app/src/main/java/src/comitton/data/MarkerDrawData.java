package src.comitton.data;

public class MarkerDrawData {
	public float mX1;
	public float mY1;
	public float mX2;
	public float mY2;
}
