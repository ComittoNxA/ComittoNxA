var searchData=
[
  ['tjhandle',['tjhandle',['../group___turbo_j_p_e_g.html#ga758d2634ecb4949de7815cba621f5763',1,'turbojpeg.h']]],
  ['tjtransform',['tjtransform',['../group___turbo_j_p_e_g.html#gaa29f3189c41be12ec5dee7caec318a31',1,'turbojpeg.h']]]
];
