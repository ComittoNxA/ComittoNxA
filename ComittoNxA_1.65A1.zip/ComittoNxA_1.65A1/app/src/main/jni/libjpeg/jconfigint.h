/* libjpeg-turbo build number */
#undef BUILD

/* How to obtain function inlining. */
#define INLINE

/* Define to the full name of this package. */
#undef PACKAGE_NAME

/* Version number of package */
#undef VERSION
